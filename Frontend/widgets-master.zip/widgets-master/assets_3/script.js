Keukenhof.init({
    hasAnimation: true,
});
