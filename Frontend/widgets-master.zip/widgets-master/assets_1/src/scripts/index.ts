export const log = (message: string) => {
  console.log(message);
};
